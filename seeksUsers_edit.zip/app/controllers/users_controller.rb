class UsersController < ApplicationController
  def index
  end

  def new
  end

  def show
    @user = User.find(params[:id])
  end

  def create
    if params[:user][:password] == params[:user][:password_confirmation]
      puts "Params[:password]: #{params[:user][:password]}"
      puts "Params[:password_confirmation]: #{params[:user][:password_confirmation]}"
      @user = User.new(user_params)
      puts "******** #{@user}"
      puts @user.password
      if !@user.valid?
        flash[:errors] = @user.errors.full_messages
        redirect_to '/users/new'
      else
        @user.save
        redirect_to "/users/#{@user.id}"
      end
    end
  end

  def edit
  end


  private

  def user_params
    params.require(:user).permit(:name, :email, :password)
  end
end

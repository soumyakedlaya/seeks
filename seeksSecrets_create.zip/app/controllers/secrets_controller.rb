class SecretsController < ApplicationController
  def index
    @secrets = Secret.all
  end

  def create
    @user = User.find(params[:id])
    @secret = @user.secrets.create(secrets_params)
    if !@secret.valid?
      initialize_flash
      flash[:errors] << @secret.errors.full_messages
      redirect_to "/users/#{@user.id}"
    else
      @secret.save
      redirect_to "/users/#{@user.id}"
    end
  end

  private
    def secrets_params
      params.require(:secret).permit(:content, :user_id)
    end
end

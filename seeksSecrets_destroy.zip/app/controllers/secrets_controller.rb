class SecretsController < ApplicationController
  def index
    @secrets = Secret.all
  end

  def create
    @user = User.find(params[:id])
    @secret = @user.secrets.create(secrets_params)
    if !@secret.valid?
      initialize_flash
      flash[:errors] << @secret.errors.full_messages
      redirect_to "/users/#{@user.id}"
    else
      @secret.save
      redirect_to "/users/#{@user.id}"
    end
  end

  def destroy
    secret = Secret.find(params[:id])
    # binding.pry
    if secret.user_id == current_user.id
      secret.destroy!
      redirect_to "/users/#{secret.user_id}"
    else
      redirect_to "/secrets"
    end
  end

  private
    def secrets_params
      params.require(:secret).permit(:content, :user_id)
    end
end
